#!/bin/sh
#$ -V
#$ -cwd
#$ -S /bin/bash
#$ -N MPI_Jobs
#$ -o $JOB_NAME.o$JOB_ID
#$ -e $JOB_NAME.e$JOB_ID
#$ -q omni
#$ -pe mpi 72
#$ -l h_vmem=5.3G
#$ -l h_rt=00:05:00

#$ -P finals 

module purge
module load intel openmpi

echo "Testing mpi_matrixmul.exe -np 1 ./mpi_matrixmul.exe 2000..."
mpirun --machinefile machinefile.$JOB_ID -np 1  ./mpi_matrixmul.exe 2000
echo -e "###\n"
echo "Testing mpi_matrixmul.exe -np 2 -npernode 1 ./mpi_matrixmul.exe 2000 ..."
mpirun --machinefile machinefile.$JOB_ID -np 2 -npernode 1 ./mpi_matrixmul.exe 2000
echo -e "###\n"
echo "Testing mpi_matrixmul.exe -np 4 -npernode 2 ./mpi_matrixmul.exe 2000..."
mpirun --machinefile machinefile.$JOB_ID -np 4 -npernode 2 ./mpi_matrixmul.exe 2000
echo -e "###\n"
echo "Testing mpi_matrixmul.exe -np 8 -npernode 4 ./mpi_matrixmul.exe 2000..."
mpirun --machinefile machinefile.$JOB_ID -np 8 -npernode 4 ./mpi_matrixmul.exe 2000
echo -e "###\n"
echo "Testing mpi_matrixmul.exe -np 16 -npernode 8 ./mpi_matrixmul.exe 2000..."
mpirun --machinefile machinefile.$JOB_ID -np 16 -npernode 8 ./mpi_matrixmul.exe 2000
echo -e "###\n"
echo "Testing mpi_matrixmul.exe -np 32 -npernode 16 ./mpi_matrixmul.exe 2000..."
mpirun --machinefile machinefile.$JOB_ID -np 32 -npernode 16 ./mpi_matrixmul.exe 2000
echo -e "###\n"
echo "Testing mpi_matrixmul.exe -np 64 -npernode 32 ./mpi_matrixmul.exe 2000..."
mpirun --machinefile machinefile.$JOB_ID -np 64 -npernode 32 ./mpi_matrixmul.exe 2000
echo -e "###\n"

