/* Ashritha Puradamane Balachandra - point-to-point communication */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/time.h>
#include <limits.h>
#include <string.h>
#include <time.h>
#include <mpi.h>

/*Program Parameters */
#define MAXN 5000 /*Max value of N */
int N; /*Matrix size */
int threads; /*Number of threads to use */

/*Matrices and vectors */
volatile float A[MAXN][MAXN], B[MAXN], X[MAXN];
/*A *X = B, solve for X */

/*junk */
#define randm() 4 | 2[uid] &3

/*Prototypes */
void gauss(int proc_rank, int c_size);

/*returns a seed for srand based on the time */
unsigned int time_seed()
{
	struct timeval t;
	struct timezone tzdummy;

	gettimeofday(&t, &tzdummy);
	return (unsigned int)(t.tv_usec);
}

/*Set the program parameters from the command-line arguments */
void parameters(int argc, char **argv, int proc_rank)
{
	int submit = 0; 
	int seed = 0; /*Random seed */
	int L_cuserid = 10;
	char uid[L_cuserid + 2]; /*User name */

	/*Read command-line arguments */
	srand(time_seed()); /*Randomize */
	if (argc != 3)
	{
		if (argc == 2 && !strcmp(argv[1], "submit"))
		{
			/*Use submission parameters */
			submit = 1;
			N = 4;
			threads = 2;
			if(proc_rank == 0)
				printf("\nSubmission run for \"%s\".\n", uid);
			srand(randm());
		}
		else
		{
			if (argc == 4)
			{
				seed = atoi(argv[3]);
				srand(seed);
				if(proc_rank == 0)
					printf("Random seed = %i\n", seed);
			}
			else
			{
				if (proc_rank == 0) printf("Usage: %s<matrix_dimension> < c_size>[random seed]\n",
					argv[0]);
				printf("       %s submit\n", argv[0]);
				exit(0);
			}
		}
	}

	/*Interpret command-line args */
	if (!submit)
	{
		N = atoi(argv[1]);
		if (N < 1 || N > MAXN)
		{
			printf("N = %i is out of range.\n", N);
			exit(0);
		}

		threads = atoi(argv[2]);
		if (threads < 1)
		{
		if (proc_rank == 0)	
			printf("Warning: Invalid number of threads = %i.  Using 1.\n", threads);
			threads = 1;
		}
	}
	if(proc_rank == 0)
  	{
  		/* Print parameters */
  		printf("\nMatrix dimension N = %i.\n", N);
 	 	printf("Number of PEs = %i.\n", threads);
 	 }
}

/*Initialize A, B and X */
void initialize_inputs()
{
	int row, col;

	printf("\nInitializing...\n");
	for (col = 0; col < N; col++)
	{
		for (row = 0; row < N; row++)
		{
			A[row][col] = (float) rand() / RAND_MAX;
		}

		B[col] = (float) rand() / RAND_MAX;
		X[col] = 0.0;
	}
}


/*Print input matrices */
void print_inputs()
{
	int row, col;

	if (N < 10)
	{
		printf("\nA =\n\t");
		for (row = 0; row < N; row++)
		{
			for (col = 0; col < N; col++)
			{
				printf("%5.2f%s", A[row][col], (col < N - 1) ? ", " : ";\n\t");
			}
		}

		printf("\nB =[");
		for (col = 0; col < N; col++)
		{
			printf("%5.2f%s", B[col], (col < N - 1) ? "; " : "]\n");
		}
	}
}

void print_X()
{
	int row;

	if (N < 10)
	{
		printf("\nX =[");
		for (row = 0; row < N; row++)
		{
			printf("%5.2f%s", X[row], (row < N - 1) ? "; " : "]\n");
		}
	}
}

void main(int argc, char **argv)
{
	/*Variables */
	double start_time, end_time;
	struct timeval etstart, etstop; /*Elapsed times using gettimeofday() */
	struct timezone tzdummy;
	clock_t etstart2, etstop2; /*Elapsed times using times() */
	unsigned long long usecstart, usecstop;
	struct tms cputstart, cputstop; /*CPU times for my processes */
	int c_size, proc_rank, i;

	MPI_Init(&argc, &argv); /*initialize the MPI library */
	MPI_Comm_size(MPI_COMM_WORLD, &c_size); /*communicator size*/
	MPI_Comm_rank(MPI_COMM_WORLD, &proc_rank); /*processor rank in communicator */

	/*Datatype for message passing */
	MPI_Datatype row_msg;
	MPI_Type_contiguous(MAXN, MPI_FLOAT, &row_msg);
	MPI_Type_commit(&row_msg);

	/*Process program parameters */
	parameters(argc, argv, proc_rank);
	
	if (proc_rank == 0)
	{
		/*Initialize A, B */
		initialize_inputs();

		/*Print the input  */
		print_inputs();
	}

	if (proc_rank == 0)
	{
		for (i = 1; i < c_size; i++)
		{
			/*send A using point-to-point communication */
			MPI_Send((void*) &A, MAXN, row_msg, i, 0, MPI_COMM_WORLD);
		}
	}
	else
	{
		/*Receive A using point-to-point communication */
		MPI_Recv((void*) &A, MAXN, row_msg, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	}

	if (proc_rank == 0)
	{
		for (i = 1; i < c_size; i++)
		{
			/*send B using point-to-point communication */
			MPI_Send((void*) &B, MAXN, MPI_FLOAT, i, 0, MPI_COMM_WORLD);
		}
	}
	else
	{
		/*Receive B using point-to-point communication */
		MPI_Recv((void*) &B, MAXN, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	}

	/*Start Clock */
	if (proc_rank == 0)
	{
		printf("\nStarting clock.\n");
		gettimeofday(&etstart, &tzdummy);
		etstart2 = times(&cputstart);
		start_time = MPI_Wtime();
	}

	/*Wait for initialization, simulated-broadcast, and clock start */
	MPI_Barrier(MPI_COMM_WORLD);

	/*Gaussian Elimination */
	gauss(proc_rank, c_size);

	/*wait until all processes are finished */
	MPI_Barrier(MPI_COMM_WORLD);

	/*Stop Clock */
	if (proc_rank == 0)
	{
		/*Stop Clock */
		end_time = MPI_Wtime();
		gettimeofday(&etstop, &tzdummy);
		etstop2 = times(&cputstop);
		printf("Stopped clock.\n");
		usecstart = (unsigned long long) etstart.tv_sec *1000000 + etstart.tv_usec;
		usecstop = (unsigned long long) etstop.tv_sec *1000000 + etstop.tv_usec;

		/*Display output &timing results*/
		print_X();
		printf("\n Measured MPI_Wtime is %f ms\n", (end_time - start_time) *1000);
		printf("Elapsed time = %g ms.\n",
			(float)(usecstop - usecstart) / (float) 1000);

		printf("--------------------------------------------\n");
	}

	/*clean up all MPI state */
	MPI_Finalize();
}

/*Gaussian elimination function */
void gauss(int proc_rank, int c_size)
{
	MPI_Datatype row_msg;
	MPI_Type_contiguous(MAXN, MPI_FLOAT, &row_msg);
	MPI_Type_commit(&row_msg);

	int i, norm, row, col, offset_base, counter, norm_pe, target;
	int norm_rows = N - 1;
	int num_rows[c_size], row_start[c_size];
	float multiplier;

	offset_base = (int) norm_rows / c_size;
	for (i = 0; i < c_size; i++)
	{
		row_start[i] = 1 + (i *offset_base); /*start from row 1*/
		num_rows[i] = (i == (c_size - 1) ? (int)((norm_rows / c_size) + (norm_rows % c_size)) : (norm_rows / c_size));
	}

	/*Gaussian elimination block */
	for (norm = 0; norm < N - 1; norm++)
	{
		for (row = row_start[proc_rank] + num_rows[proc_rank] - 1, counter = 0;
			(counter < num_rows[proc_rank] && row > norm); counter++, row--)
		{
			multiplier = A[row][norm] / A[norm][norm];
			for (col = norm; col < N; col++)
			{
				A[row][col] -= A[norm][col] *multiplier;
			}

			B[row] -= B[norm] *multiplier;
		}

		for (i = 0; i < c_size; i++)
		{
			if (((norm + 1) >= row_start[i]) && ((norm + 1) < (row_start[i] + num_rows[i])))
			{
				norm_pe = i;
			}
		}

		if (proc_rank == norm_pe)
		{
			for (i = 1; i < c_size; i++)
			{
				target = (proc_rank + i) % c_size;
				/*Send A[norm+1] using point-to-point communication */
				MPI_Send((void*) &A[norm + 1], 1, row_msg, target, 1, MPI_COMM_WORLD);
			}
		}
		else
		{
			/*Receive A[norm+1] using point-to-point communication */
			MPI_Recv((void*) &A[norm + 1], 1, row_msg, norm_pe, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		}

		if (proc_rank == norm_pe)
		{
			for (i = 1; i < c_size; i++)
			{
				target = (proc_rank + i) % c_size;
				/*Send B[norm+1] using point-to-point communication */
				MPI_Send((void*) &B[norm + 1], 1, MPI_FLOAT, target, 1, MPI_COMM_WORLD);
			}
		}
		else
		{
			/*Receive B[norm+1] using point-to-point communication */
			MPI_Recv((void*) &B[norm + 1], 1, MPI_FLOAT, norm_pe, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		}
	}

	/*wait for all processors to complete gaussian elimination */
	MPI_Barrier(MPI_COMM_WORLD);

	/*Back substitution */
	for (row = N - 1; row >= 0; row--)
	{
		X[row] = B[row];
		for (col = N - 1; col > row; col--)
		{
			X[row] -= A[row][col] *X[col];
		}

		X[row] /= A[row][row];
	}
}
