#!/bin/sh
#$ -V
#$ -cwd
#$ -S /bin/bash
#$ -N MPI_Jobs
#$ -o $JOB_NAME.o$JOB_ID
#$ -e $JOB_NAME.e$JOB_ID
#$ -q omni
#$ -pe mpi 72
#$ -l h_vmem=5.3G
#$ -l h_rt=00:05:00
#$ -P finals 

module purge
module load intel openmpi

echo "Testing point_to_point_communication.exe for -np 1 ..."
mpirun --machinefile machinefile.$JOB_ID -np 1 ./point_to_point_communication.exe 2000 1
echo -e "###\n"

echo "Testing point_to_point_communication.exe for -np 2..."
mpirun --machinefile machinefile.$JOB_ID -np 2 -npernode 1 ./point_to_point_communication.exe 2000 2
echo -e "###\n"
echo "Testing point_to_point_communication.exe for -np 4..."
mpirun --machinefile machinefile.$JOB_ID -np 4 -npernode 2 ./point_to_point_communication.exe 2000 4
echo -e "###\n"
echo "Testing point_to_point_communication.exe for -np 8..."
mpirun --machinefile machinefile.$JOB_ID -np 8 -npernode 4 ./point_to_point_communication.exe 2000 8
echo -e "###\n"
echo "Testing point_to_point_communication.exe for -np 16..."
mpirun --machinefile machinefile.$JOB_ID -np 16 -npernode 8 ./point_to_point_communication.exe 2000 16
echo -e "###\n"
echo "Testing point_to_point_communication.exe for -np 32..."
mpirun --machinefile machinefile.$JOB_ID -np 32 -npernode 16 ./point_to_point_communication.exe 2000 32
echo -e "###\n"
echo "Testing point_to_point_communication.exe -np 64..."
mpirun --machinefile machinefile.$JOB_ID -np 64 -npernode 32 ./point_to_point_communication.exe 2000 64
echo -e "###\n"

echo "Testing gauss_collective.exe for -np 1 ..."
mpirun --machinefile machinefile.$JOB_ID -np 1 ./gauss_collective.exe 2000 1
echo -e "###\n"
echo "Testing gauss_collective.exe for -np 2..."
mpirun --machinefile machinefile.$JOB_ID -np 2 -npernode 1 ./gauss_collective.exe 2000 2
echo -e "###\n"
echo "Testing gauss_collective.exe for -np 4..."
mpirun --machinefile machinefile.$JOB_ID -np 4 -npernode 2 ./gauss_collective.exe 2000 4
echo -e "###\n"
echo "Testing gauss_collective.exe for -np 8..."
mpirun --machinefile machinefile.$JOB_ID -np 8 -npernode 4 ./gauss_collective.exe 2000 8
echo -e "###\n"
echo "Testing gauss_collective.exe for -np 16..."
mpirun --machinefile machinefile.$JOB_ID -np 16 -npernode 8 ./gauss_collective.exe 2000 16
echo -e "###\n"
echo "Testing gauss_collective.exe for -np 32..."
mpirun --machinefile machinefile.$JOB_ID -np 32 -npernode 16 ./gauss_collective.exe 2000 32
echo -e "###\n"
echo "Testing gauss_collective.exe -np 64..."
mpirun --machinefile machinefile.$JOB_ID -np 64 -npernode 32 ./gauss_collective.exe 2000 64
echo -e "###\n"

