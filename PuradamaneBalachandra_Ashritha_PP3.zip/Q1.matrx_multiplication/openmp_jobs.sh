#!/bin/sh
#$ -V
#$ -cwd
#$ -S /bin/bash
#$ -N OpenMP_matrix_Job
#$ -o $JOB_NAME.o$JOB_ID
#$ -e $JOB_NAME.e$JOB_ID
#$ -q omni
#$ -pe sm 36
#$ -l h_vmem=5.3G
#$ -l h_rt=01:00:00
#$ -P quanah

module load gnu openmpi 

echo "innermost_loop_parallelized.exe ..."
./innermost_loop_parallelized.exe
echo -e "###\n"

echo "Testing two_loops_parallelized.exe ..."
./two_loops_parallelized.exe
echo -e "###\n"

echo "Testing all_loops_parallelized.exe ..."
./all_loops_parallelized.exe
echo -e "###\n"

echo "innermost_loop_parallelized.exe ..."
export OMP_NUM_THREADS=1
./innermost_loop_parallelized.exe
export OMP_NUM_THREADS=2
./innermost_loop_parallelized.exe
export OMP_NUM_THREADS=4
./innermost_loop_parallelized.exe
export OMP_NUM_THREADS=8
./innermost_loop_parallelized.exe
export OMP_NUM_THREADS=16
./innermost_loop_parallelized.exe
export OMP_NUM_THREADS=32
./innermost_loop_parallelized.exe
echo -e "###\n"

echo "two_loops_parallelized.exe ..."
export OMP_NUM_THREADS=1
./two_loops_parallelized.exe
export OMP_NUM_THREADS=2
./two_loops_parallelized.exe
export OMP_NUM_THREADS=4
./two_loops_parallelized.exe
export OMP_NUM_THREADS=8
./two_loops_parallelized.exe
export OMP_NUM_THREADS=16
./two_loops_parallelized.exe
export OMP_NUM_THREADS=32
./two_loops_parallelized.exe
echo -e "###\n"

echo "all_loops_parallelized.exe ..."
export OMP_NUM_THREADS=1
./all_loops_parallelized.exe
export OMP_NUM_THREADS=2
./all_loops_parallelized.exe
export OMP_NUM_THREADS=4
./all_loops_parallelized.exe
export OMP_NUM_THREADS=8
./all_loops_parallelized.exe
export OMP_NUM_THREADS=16
./all_loops_parallelized.exe
export OMP_NUM_THREADS=32
./all_loops_parallelized.exe
echo -e "###\n"



