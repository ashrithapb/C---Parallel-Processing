#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <sys/time.h>

#define N 10	
int A[N][N];
int B[N][N];
int C[N][N];

static double 
mysecond()
{
	struct timeval	tp;
	struct timezone	tzp;
	int i = 0;

	i = gettimeofday(&tp, &tzp);
	return ((double)tp.tv_sec + (double)tp.tv_usec * 1.e-6);
}

int main(int argc, char **argv) 
{
	int i,j,k;
	double elapsed;
	int num_th; 
	int n = 4;// matrix dimension
	double start = 0.0;
	double end = 0.0;    

	for (i= 0; i< n; i++){
        	for (j= 0; j< n; j++){
            		A[i][j] = 2;
            		B[i][j] = 2;
		}
	}
	start = mysecond();
	#pragma omp parallel private(i,j,k) shared(A,B,C)
	{
		#pragma omp for schedule(static)
		for (i = 0; i < n; ++i) {
        		for (j = 0; j < n; ++j) {
            			for (k = 0; k < n; ++k) {
                			C[i][j] += A[i][k] * B[k][j];
            			}
        		}
		num_th = omp_get_num_threads();
    		}
	}
	end = mysecond();
	printf("Runtime of %d threads = %f seconds\n", num_th, (end - start));
	for (i= 0; i< n; i++)
    	{
        	for (j= 0; j< n; j++)
        	{
            		printf("%d\t",C[i][j]);
        	}
        	printf("\n");
    	}
}
