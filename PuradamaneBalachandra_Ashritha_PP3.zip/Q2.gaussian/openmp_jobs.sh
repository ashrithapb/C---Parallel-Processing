#!/bin/sh
#$ -V
#$ -cwd
#$ -S /bin/bash
#$ -N Openmp_Job
#$ -o $JOB_NAME.o$JOB_ID
#$ -e $JOB_NAME.e$JOB_ID
#$ -q omni
#$ -pe sm 36
#$ -l h_vmem=5.3G
#$ -l h_rt=01:00:00
#$ -P quanah

module load gnu openmpi

echo "Testing gauss.exe ..."
./gauss.exe 3 1
./gauss.exe 3 2
./gauss.exe 3 4
./gauss.exe 3 8
./gauss.exe 3 16
./gauss.exe 3 32
echo -e "###\n"


echo "Testing gauss_openmp.exe ..."
./gauss_openmp.exe 3 1
./gauss_openmp.exe 3 2
./gauss_openmp.exe 3 4
./gauss_openmp.exe 3 8
./gauss_openmp.exe 3 16
./gauss_openmp.exe 3 32
echo -e "###\n"

echo "Testing gauss_static.exe ..."
./gauss_static.exe 3 1
./gauss_static.exe 3 2
./gauss_static.exe 3 4
./gauss_static.exe 3 8
./gauss_static.exe 3 16
./gauss_static.exe 3 32
echo -e "###\n"

echo "Testing gauss_dynamic.exe ..."
./gauss_dynamic.exe 3 1
./gauss_dynamic.exe 3 2
./gauss_dynamic.exe 3 4
./gauss_dynamic.exe 3 8
./gauss_dynamic.exe 3 16
./gauss_dynamic.exe 3 32
echo -e "###\n"


