/* Ashritha Puradamane Balachandra - Gaussian eliminatio */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/time.h>
#include <limits.h>
#include <omp.h>

/* Global variables */
#define MAXN 2000  /* Max value of N */
#define MAX_THREADS 100 /* Max number of threads */

int N;  /* Matrix size */
int procs;  /* Number of processors to use */

/* Matrices and vectors */
volatile float A[MAXN][MAXN], B[MAXN], X[MAXN];
/* A * X = B, solve for X */

/* junk */
#define randm() 4|2[uid]&3

/* Prototype */
void *gauss();  
void gauss_back_substitution();

/* returns a seed for srand based on the time */
unsigned int time_seed() {
  struct timeval t;
  struct timezone tzdummy;

  gettimeofday(&t, &tzdummy);
  return (unsigned int)(t.tv_usec);
}
/* Set the program parameters from the command-line arguments */
void parameters(int argc, char **argv) {
  int submit = 0;  /* = 1 if submission parameters should be used */
  int seed = 0;  /* Random seed */
	int L_cuserid = 10;
  char uid[L_cuserid + 2]; /*User name */

  /* Read command-line arguments */
  srand(time_seed());  /* Randomize */
  if (argc != 3) {
    if ( argc == 2 && !strcmp(argv[1], "submit") ) {
      /* Use submission parameters */
      submit = 1;
      N = 4;
      procs = 2;
      printf("\nSubmission run for \"%s\".\n", cuserid(uid));
      srand(randm());
    }
    else {
      if (argc == 4) {
	seed = atoi(argv[3]);
	srand(seed);
	printf("Random seed = %i\n", seed);
      }
      else {
	printf("Usage: %s <matrix_dimension> <num_procs> [random seed]\n",
	       argv[0]);
	printf("       %s submit\n", argv[0]);
	exit(0);
      }
    }
  }
  /* Interpret command-line args */
  if (!submit) {
    N = atoi(argv[1]);
    if (N < 1 || N > MAXN) {
      printf("N = %i is out of range.\n", N);
      exit(0);
    }
    procs = atoi(argv[2]);
    if (procs < 1) {
      printf("Warning: Invalid number of processors = %i.  Using 1.\n", procs);
      procs = 1;
    }
    if (procs > m_get_numprocs()) {
      printf("Warning: %i processors requested; only %i available.\n",
	     procs, m_get_numprocs());
      procs = m_get_numprocs();
    }
  }

  /* Print parameters */
  printf("\nMatrix dimension N = %i.\n", N);
  printf("Number of processors = %i.\n", procs);

  /* Set number of processors */
 // m_set_procs(procs);
}

int m_get_numprocs(){
        return MAX_THREADS;
}

/* Initialize A and B (and X to 0.0s) */
void initialize_inputs() {
  int row, col;

  printf("\nInitializing...\n");
  for (col = 0; col < N; col++) {
    for (row = 0; row < N; row++) {
      A[row][col] = (float)rand() / RAND_MAX;
    }
    B[col] = (float)rand() / RAND_MAX;
    X[col] = 0.0;
  }

}

/* Print input matrices */
void print_inputs() {
  int row, col;

  if (N < 10) {
    printf("\nA =\n\t");
    for (row = 0; row < N; row++) {
      for (col = 0; col < N; col++) {
	printf("%5.2f%s", A[row][col], (col < N-1) ? ", " : ";\n\t");
      }
    }
    printf("\nB = [");
    for (col = 0; col < N; col++) {
      printf("%5.2f%s", B[col], (col < N-1) ? "; " : "]\n");
    }
  }
}

void print_X() {
  int row;

  if (N < 10) {
    printf("\nX = [");
    for (row = 0; row < N; row++) {
      printf("%5.2f%s", X[row], (row < N-1) ? "; " : "]\n");
    }
  }
}
void main(int argc, char **argv) {
  /* Timing variables */
  	struct timeval etstart, etstop;  /* Elapsed times using gettimeofday() */
	struct timezone tzdummy;
  	clock_t etstart2, etstop2;  /* Elapsed times using times() */
	unsigned long long usecstart, usecstop;
 	struct tms cputstart, cputstop;  /* CPU times for my processes */
	int i;
	int status;
	float CLK_TCK;
  	/* Process program parameters */
  	parameters(argc, argv);

  	/* Initialize A and B */
  	initialize_inputs();

  	/* Print input matrices */
  	print_inputs();
	
	/* Start Clock */
  	printf("\nStarting clock.\n");
  	gettimeofday(&etstart, &tzdummy);
  	etstart2 = times(&cputstart);
	
	gauss();
	gauss_back_substitution();

 	/* Stop Clock */
  	gettimeofday(&etstop, &tzdummy);
  	etstop2 = times(&cputstop);
  	printf("Stopped clock.\n");
  	usecstart = (unsigned long long)etstart.tv_sec * 1000000 + etstart.tv_usec;
  	usecstop = (unsigned long long)etstop.tv_sec * 1000000 + etstop.tv_usec;

  	/* Display output */
  	print_X();

  	/* Display timing results */
  	printf("\nElapsed time = %g ms.\n",
	 (float)(usecstop - usecstart)/(float)1000);
	printf("--------------------------------------------\n");

}

void *gauss() {
  	int norm, row, col;  /* Normalization row, and zeroing
			* element row and col */
  	float multiplier;

  	/* Gaussian elimination - parallelization applied to for loops using openMP : variables row,col,multiplier are made private. A and B are shared across all threads */
  	#pragma omp parallel for num_threads(MAX_THREADS) private(row,col,multiplier) shared(A,B)
  	for (norm = 0; norm < N - 1; norm++) {
    		for (row = norm + 1; row < N; row++) {
      			multiplier = A[row][norm] / A[norm][norm];
      			for (col = norm; col < N; col++) {
				A[row][col] -= A[norm][col] * multiplier;
      			}
      			B[row] -= B[norm] * multiplier;
    		}
  	}
}
  /* (Diagonal elements are not normalized to 1.  This is treated in back
 *    * substitution.)
 *       */

  /* Back substitution method*/
void gauss_back_substitution(){
	int row, col;
	for (row = N - 1; row >= 0; row--) {
    		X[row] = B[row];
    		for (col = N-1; col > row; col--) {
      			X[row] -= A[row][col] * X[col];
    		}
    		X[row] /= A[row][row];
  	}
}

