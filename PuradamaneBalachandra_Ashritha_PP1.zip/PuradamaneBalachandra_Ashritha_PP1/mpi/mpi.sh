#!/bin/sh
#$ -V
#$ -cwd
#$ -S /bin/bash
#$ -N Ashritha_MPI_Test
#$ -o $JOB_NAME.o$JOB_ID
#$ -e $JOB_NAME.e$JOB_ID
#$ -q omni
#$ -pe mpi 36
#$ -l h_vmem=2G
#$ -l h_rt=00:05:00
#$ -P quanah

module load intel impi

mpirun --machinefile machinefile.$JOB_ID -np $NSLOTS ./mpi_hello_world-intel-impi
