#!/bin/sh
#$ -V
#$ -cwd
#$ -S /bin/bash
#$ -N Pthreads_Job
#$ -o $JOB_NAME.o$JOB_ID
#$ -e $JOB_NAME.e$JOB_ID
#$ -q omni
#$ -pe sm 36
#$ -l h_vmem=5.3G
#$ -l h_rt=01:00:00
#$ -P quanah

echo "Testing logbarrier.exe ..."
./logbarrier.exe
echo -e "###\n"

echo "Testing logbarrier.exe ..."
./logbarrier.exe 3 1 10
./logbarrier.exe 3 2 10
./logbarrier.exe 3 4 10
./logbarrier.exe 3 8 10
./logbarrier.exe 3 16 10
./logbarrier.exe 3 2 10 
echo -e "###\n"

