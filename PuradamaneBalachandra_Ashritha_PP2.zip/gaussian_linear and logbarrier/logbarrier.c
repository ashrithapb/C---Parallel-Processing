/* Ashritha Puradamane Balachandra - Gaussian elimination with tree/log barrier */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/time.h>
#include <limits.h>
#include <pthread.h>

typedef struct barrier_node {
        pthread_mutex_t count_lock;
        pthread_cond_t ok_to_proceed_up;
        pthread_cond_t ok_to_proceed_down;
        int count;
} mylib_barrier_t_internal;

/* Program Parameters */
#define MAXN 2000  /* Max value of N */
#define MAX_THREADS 100 /* Max number of threads */
pthread_t threads[MAX_THREADS];

typedef struct barrier_node mylob_logbarrier_t[MAX_THREADS];
pthread_attr_t attr;
mylob_logbarrier_t b;

int N;  /* Matrix size */
int procs;  /* Number of processors to use */

/* Matrices and vectors */
volatile float A[MAXN][MAXN], B[MAXN], X[MAXN];
/* A * X = B, solve for X */

/* junk */
#define randm() 4|2[uid]&3

/* Prototype */
void *gauss(void *s);  
void gauss_back_substitution();

/* returns a seed for srand based on the time */
unsigned int time_seed() {
        struct timeval t;
        struct timezone tzdummy;

        gettimeofday(&t, &tzdummy);
        return (unsigned int)(t.tv_usec);
}

/* Set the program parameters from the command-line arguments */
void parameters(int argc, char **argv) {
        int submit = 0;  /* = 1 if submission parameters should be used */
        int seed = 0;  /* Random seed */
	      int L_cuserid = 10;
        char uid[L_cuserid + 2]; /*User name */

  /* Read command-line arguments */
        srand(time_seed());  /* Randomize */
        if (argc != 3) {
               if ( argc == 2 && !strcmp(argv[1], "submit") ) {
          /* Use submission parameters */
                    submit = 1;
                    N = 4;
                    procs = 2;
                    printf("\nSubmission run for \"%s\".\n", cuserid(uid));
                    srand(randm());
               }
                else {
                        if (argc == 4) {
                              seed = atoi(argv[3]);
                              srand(seed);
                              printf("Random seed = %i\n", seed);
                        }
                        else {
                              printf("Usage: %s <matrix_dimension> <num_procs> [random seed]\n",
                                    argv[0]);
                              printf("       %s submit\n", argv[0]);
                              exit(0);
                        }
                  }
          }
  /* Interpret command-line args */
          if (!submit) {
                N = atoi(argv[1]);
                if (N < 1 || N > MAXN) {
                        printf("N = %i is out of range.\n", N);
                        exit(0);
                }
                procs = atoi(argv[2]);
                if (procs < 1) {
                        printf("Warning: Invalid number of processors = %i.  Using 1.\n", procs);
                        procs = 1;
                }
                if (procs > m_get_numprocs()) {
                        printf("Warning: %i processors requested; only %i available.\n",
                        procs, m_get_numprocs());
                        procs = m_get_numprocs();
                }
          }

          /* Print parameters */
          printf("\nMatrix dimension N = %i.\n", N);
          printf("Number of processors = %i.\n", procs);
 }

int m_get_numprocs(){
        return MAX_THREADS;
}

/* Initialize A and B (and X to 0.0s) */
void initialize_inputs() {
        int row, col;

        printf("\nInitializing...\n");
        for (col = 0; col < N; col++) {
                for (row = 0; row < N; row++) {
                        A[row][col] = (float)rand() / (float)RAND_MAX;
                }
                B[col] = (float)rand() / (float) RAND_MAX;
                X[col] = 0.0;
        }
}

/* Print input matrices */
void print_inputs() {
        int row, col;

        if (N < 10) {
                printf("\nA =\n\t");
                for (row = 0; row < N; row++) {
                        for (col = 0; col < N; col++) {
                                printf("%5.2f%s", A[row][col], (col < N-1) ? ", " : ";\n\t");
                        }
                }
                printf("\nB = [");
                for (col = 0; col < N; col++) {
                        printf("%5.2f%s", B[col], (col < N-1) ? "; " : "]\n");
                }
        }
}

void mylib_init_barrier(mylob_logbarrier_t b)
{ /* log barrier initialixation */
        int i;
        for (i = 0; i < MAX_THREADS; i++) {
                b[i].count = 0;
                pthread_mutex_init(&(b[i].count_lock), NULL);
                pthread_cond_init(&(b[i].ok_to_proceed_up), NULL);
                pthread_cond_init(&(b[i].ok_to_proceed_down), NULL);
        }
}

void mylib_logbarrier (mylob_logbarrier_t b, int num_threads, int thread_id)
{ 
  /* threads are paired up and each pair of threads shares a single condition variable-mutex
  pair. It waits till it becomes the pairwise barrier and this process
  continues until there is only one thread. Once all threads have reached
  the barrier point, we release all threads. */
        int i, base, index;
        i = 2;
        base = 0;
        do {
                index = base + thread_id / i;
                if (thread_id % i == 0) {
                        pthread_mutex_lock(&(b[index].count_lock));
                        b[index].count ++;
                        while (b[index].count < 2)
                              pthread_cond_wait(&(b[index].ok_to_proceed_up),
                                        &(b[index].count_lock));
                        pthread_mutex_unlock(&(b[index].count_lock));
                }
                else {
                        pthread_mutex_lock(&(b[index].count_lock));
                        b[index].count ++;
                        if (b[index].count == 2)
                           pthread_cond_signal(&(b[index].ok_to_proceed_up));
			while (
                               pthread_cond_wait(&(b[index].ok_to_proceed_down),
                                    &(b[index].count_lock)) != 0);
			pthread_mutex_unlock(&(b[index].count_lock));
			break;
                }
                base = base + procs/i;
                i = i * 2; 
        } while (i <= procs);

	i = i / 2;

        for (; i > 1; i = i / 2)
        {
		base = base - procs/i;
                index = base + thread_id / i;
                pthread_mutex_lock(&(b[index].count_lock));
                b[index].count = 0;
                pthread_cond_signal(&(b[index].ok_to_proceed_down));
                pthread_mutex_unlock(&(b[index].count_lock));
        }
}
void print_X() {
      int row;
      if (N < 10) {
              printf("\nX = [");
              for (row = 0; row < N; row++) {
                     printf("%5.2f%s", X[row], (row < N-1) ? "; " : "]\n");
              }
      }
}
void main(int argc, char **argv) {
        /* Timing variables */
        struct timeval etstart, etstop;  /* Elapsed times using gettimeofday() */
        struct timezone tzdummy;
        clock_t etstart2, etstop2;  /* Elapsed times using times() */
        unsigned long long usecstart, usecstop;
        struct tms cputstart, cputstop;  /* CPU times for my processes */
        int i;
        int status;
        float CLK_TCK;
        int thread_id[MAX_THREADS];
        pthread_attr_init (&attr);

        /* Process program parameters */
        parameters(argc, argv);

        /* Initialize A and B */
        initialize_inputs();

        /* Print input matrices */
        print_inputs();
        mylib_init_barrier (b);
      /* Start Clock */
        printf("\nStarting clock.\n");
        gettimeofday(&etstart, &tzdummy);
        etstart2 = times(&cputstart);
        /* thread creation */
        for (i = 0; i < procs; i++) {
                thread_id[i]=i;
                status = pthread_create(&threads[i], &attr, gauss, (void *) &thread_id[i]);
                if (status != 0) {
                        printf("ERROR; return code from pthread_create() is %d\n", status);
                        exit(-1);
                }
        }
        for(i=0; i< procs; i++){
                pthread_join(threads[i], NULL);
        }
        gauss_back_substitution(); // calling back substitution function

        /* Stop Clock */
        gettimeofday(&etstop, &tzdummy);
        etstop2 = times(&cputstop);
        printf("Stopped clock.\n");
        usecstart = (unsigned long long)etstart.tv_sec * 1000000 + etstart.tv_usec;
        usecstop = (unsigned long long)etstop.tv_sec * 1000000 + etstop.tv_usec;

        /* Display output */
        print_X();

        /* Display timing results */
        printf("\nElapsed time = %g ms.\n",
        (float)(usecstop - usecstart)/(float)1000);
      
        printf("--------------------------------------------\n");
}

/* ------------------ Above Was Provided --------------------- */

/****** You will replace this routine with your own parallel version *******/
/* Provided global variables are MAXN, N, procs, A[][], B[], and X[],
 *  * defined in the beginning of this code.  X[] is initialized to zeros.
 *   */
void *gauss(void *s) {
        int norm, row, col;  /* Normalization row, and zeroing
            * element row and col */
        float multiplier;
        int thread_id = *((int *) s);

        /* Gaussian elimination */
        for (norm = 0; norm < N - 1; norm++) {
                for (row = norm + 1; row < N; row++) {
                        multiplier = A[row][norm] / A[norm][norm];
                        for (col = norm; col < N; col++) {
                                A[row][col] -= A[norm][col] * multiplier;
                        }
                        B[row] -= B[norm] * multiplier;
                }
        }
        /* calling log barrier function */
	if(procs >1){
        	mylib_logbarrier(b, procs, thread_id);
	}
}
  /* (Diagonal elements are not normalized to 1.  This is treated in back
 *    * substitution.)
 *       */
  /* Back substitution method*/
void gauss_back_substitution(){
        int row, col;
        for (row = N - 1; row >= 0; row--) {
                X[row] = B[row];
                for (col = N-1; col > row; col--) {
                        X[row] -= A[row][col] * X[col];
                }
                X[row] /= A[row][row];
        }
}

